-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 06, 2020 at 06:26 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.1.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hospital`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `id` int(100) NOT NULL,
  `name` varchar(50) NOT NULL,
  `age` int(10) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` int(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `date` varchar(20) NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`id`, `name`, `age`, `gender`, `email`, `phone`, `address`, `date`, `time`) VALUES
(1, 'Tasmin Farid Tonney', 23, 'female', 'tasminfaridtonney333@gmail.com', 1862887649, '', '2020-03-09', '00:00:18'),
(2, 'Tasmin Farid Tonney', 22, 'female', 'readuanulfaridfahm50@gmail.com', 1862887649, '', '2020-03-08', '00:00:17'),
(3, 'Tasmin Farid Tonney', 21, 'female', 'tasminfaridtonney333@gmail.com', 1862887649, '', '2020-03-15', '00:00:17'),
(4, 'Rasmin Farid Mim', 12, 'female', 'rasmin@gmail.com', 1862887649, '', '2020-03-23', '00:00:17'),
(5, 'fahim', 21, 'male', 'fahinm@gmail.com', 66765, '', '2020-03-02', '00:00:16'),
(6, 'sanjida', 11, 'Female', 'sanjida@gmail.com', 1862887649, '', '2020-05-18', '00:00:16'),
(7, 'Rasmin Farid Mim', 12, 'Femaile', 'mim@gmail.com', 1862887649, '', '2020-05-13', '00:00:17'),
(8, 'Rasmin Farid Mim', 12, 'Femaile', 'mim@gmail.com', 1862887649, '', '2020-05-13', '17:34:00'),
(9, 'Arfan', 24, 'Male', 'arfanahmed20@hotmail.com', 914465262, '', '2020-05-23', '13:30:00'),
(30, 'mim', 12, 'Female', 'mim@gmail.com', 984756536, 'chittagong', '2020-05-11', '18:07:00');

-- --------------------------------------------------------

--
-- Table structure for table `loginsystem`
--

CREATE TABLE `loginsystem` (
  `id` int(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `id` int(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `first_name` text NOT NULL,
  `last_name` text NOT NULL,
  `phone` int(50) NOT NULL,
  `age` int(200) NOT NULL,
  `email` varchar(300) NOT NULL,
  `location` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`id`, `username`, `image`, `first_name`, `last_name`, `phone`, `age`, `email`, `location`) VALUES
(1, '', '', 'Tasmin Farid', 'Tonney', 1862887649, 23, 'tasminfaridtonney333@gmail.com', 'Lalkhanbazar,Chittagong'),
(4, '', '', 'Rasmin Farid', ' Mim', 1862887649, 12, 'mim@gmail.com', 'lalkhanbazar'),
(6, '', '', 'Tasmin Farid', 'Tonney', 1862887649, 21, 'tonney@gmail.com', 'Lalkhanbazar,Chittagong'),
(14, '', '', 'Asifaturz Ferdozi', 'Choity', 12345645, 22, 'ferdousi70@gmail.com', 'Devpahar,Chittagong');

-- --------------------------------------------------------

--
-- Table structure for table `pharmacist`
--

CREATE TABLE `pharmacist` (
  `id` int(100) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(300) NOT NULL,
  `phone` int(20) NOT NULL,
  `NID` varchar(300) NOT NULL,
  `address` varchar(100) NOT NULL,
  `prescription` varchar(100) NOT NULL,
  `card_number` varchar(100) NOT NULL,
  `cv_code` varchar(100) NOT NULL,
  `card_owner` varchar(100) NOT NULL,
  `bekash` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pharmacist`
--

INSERT INTO `pharmacist` (`id`, `name`, `email`, `phone`, `NID`, `address`, `prescription`, `card_number`, `cv_code`, `card_owner`, `bekash`) VALUES
(1, '', '', 0, 'tonney', '', '', '0', '0', '', '0'),
(2, 'Tasmin Farid Tonney', 'tasminfaridtonney333@gmail.com', 1862887649, '1234567', '', '', '0', '0', '', '0'),
(3, 'Rasmin Farid Mim', 'mim@gmail.com', 1862887649, '1234567', '', '', '0', '0', '', '0'),
(4, 'isly', 'isly@gmail.com', 123, '123454567', '', '', '0', '0', '', '0'),
(5, 'mim', 'mim@gmail.com', 1233566, '3456', '', '', '0', '0', '', '0'),
(6, 'mim', '', 0, '', '', '', '0', '0', '', '0'),
(7, 'Rasmin Farid Mim', 'mim@gmail.com', 1862887649, '123454567', 'lalkahnbazar', '', '0', '0', '', '0'),
(8, 'TONNEY333', 'tonney@gmail.com', 1862887649, '123456789', 'Chittagong', '', '0', '0', '', '0'),
(9, 'TONNEY333', 'tonney@gmail.com', 1862887649, '123456789', 'Chittagong', '', '0', '0', '', '0'),
(10, 'Tasmin Farid Tonney', 'tasminfaridtonney333@gmail.com', 1862887649, '1234', 'lalkahnbazar', '', '0', '0', '', '0'),
(11, 'Tasmin Farid Tonney', 'tasminfaridtonney333@gmail.com', 1862887649, '1234', 'lalkahnbazar', '', '', '', '', ''),
(12, 'mim', 'mim@gmail.com', 12345, '12345678', 'Chittagong', '', '', '', '', ''),
(13, 'mim', 'mim@gmail.com', 12345, '12345678', 'Chittagong', '', '', '', '', ''),
(14, 'Rasmin Farid Mim', 'mim@gmail.com', 984756536, '234576859700123', 'Lalkhanbazr', '', '', '', '', ''),
(15, 'Rasmin Farid Mim', 'mim@gmail.com', 984756536, '234576859700123', 'Lalkhanbazr', '', '', '', '', ''),
(16, 'Arfan', 'arfanahmed20@hotmail.com', 12345678, '12321456787456', 'Oxigen', '', '', '', '', ''),
(17, 'tonney', 'tonney@gmail.com', 1862887649, '4547474344', 'Chittagong', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `sign_in`
--

CREATE TABLE `sign_in` (
  `id` int(11) NOT NULL,
  `email` varchar(225) NOT NULL,
  `password` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sign_in`
--

INSERT INTO `sign_in` (`id`, `email`, `password`) VALUES
(1, 'tasminfaridtonney333@gmail.com', '$2y$10$NJw7jUsHyiA45ht1pk2RjOEPSDcSsLfHPemaPO8UZx2/PiwCkKC52'),
(2, 'mim@gmail.com', '$2y$10$T/3aFldj8hgJFCA.uYWVJuSAGcrEMCM0v1eLXgGtTyf6jkrxZrua6');

-- --------------------------------------------------------

--
-- Table structure for table `sign_up`
--

CREATE TABLE `sign_up` (
  `id` int(11) NOT NULL,
  `profilepic` varchar(100) NOT NULL,
  `name` varchar(200) NOT NULL,
  `age` int(30) NOT NULL,
  `gender` varchar(1) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` bigint(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `NID` int(50) NOT NULL,
  `pass` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sign_up`
--

INSERT INTO `sign_up` (`id`, `profilepic`, `name`, `age`, `gender`, `email`, `phone`, `address`, `NID`, `pass`) VALUES
(4, '', 'tonney', 21, '', 'tonney@gmail.com', 1862887649, 'Lalkhanbazar', 2147483647, ''),
(5, '', 'mim', 10, '', 'mim@gmail.com', 12345645, 'Chittagong', 2147483647, '1234'),
(6, 'WhatsApp Image 2019-11-21 at 11.44.58 PM (2).jpeg', 'tasmin', 20, '', 'tasmin@gmail.com', 1862887649, 'LalkhanBazar', 2147483647, '123456'),
(7, '8.jpeg', 'baitul', 20, '', 'baitul@gmail.com', 1862887649, 'Khulsi,Chittagong', 2147483647, '12345678'),
(8, '8.jpeg', 'baitul', 20, '', 'baitul@gmail.com', 1862887649, 'Khulsi,Chittagong', 2147483647, '12345678'),
(9, '62453034_2250400275277801_2395638225478615040_o.jpg', 'Tasmin Farid Tonney', 22, '', 'tonney@gmail.com', 1862887649, 'LalkhanBazar,Chittagong', 2147483647, 'tonney123'),
(10, '62453034_2250400275277801_2395638225478615040_o.jpg', 'Tasmin Farid Tonney', 22, '', 'tonney@gmail.com', 1862887649, 'LalkhanBazar,Chittagong', 2147483647, 'tonney123'),
(11, '62453034_2250400275277801_2395638225478615040_o.jpg', 'Tasmin Farid Tonney', 22, '', 'tonney@gmail.com', 1862887649, 'LalkhanBazar,Chittagong', 2147483647, 'tonney123'),
(12, 'Screenshot (65).png', 'Rasmin Farid Mim', 13, '', 'mim@gmail.com', 1862887649, 'Chittagong', 2147483647, 'mim123'),
(13, 'Screenshot (65).png', 'Rasmin Farid Mim', 13, '', 'mim@gmail.com', 1862887649, 'Chittagong', 2147483647, 'mim123'),
(14, '', 'Tasmin Farid Tonney', 21, '', 'tasminfaridtonney333@gmail.com', 1862887649, 'lalkhanbazar', 2147483647, 'mimtonney'),
(15, '5.jpeg', 'Rasheda Akter', 30, '', 'rasheda@gmail.com', 1862887649, 'Chondonish', 2147483647, 'rasheda123'),
(16, '5.jpeg', 'Rasheda Akter', 30, '', 'rasheda@gmail.com', 1862887649, 'Chondonish', 2147483647, 'rasheda123'),
(17, '5.jpeg', 'Rasheda Akter', 30, '', 'rasheda@gmail.com', 1862887649, 'Chondonish', 2147483647, 'rasheda123'),
(18, '5.jpeg', 'Rasheda Akter', 30, '', 'rasheda@gmail.com', 1862887649, 'Chondonish', 2147483647, 'rasheda123'),
(19, '5.jpeg', 'Rasheda Akter', 30, '', 'rasheda@gmail.com', 1862887649, 'Chondonish', 2147483647, 'rasheda123'),
(20, '5.jpeg', 'Rasheda Akter', 30, '', 'rasheda@gmail.com', 1862887649, 'Chondonish', 2147483647, 'rasheda123'),
(21, '5.jpeg', 'Rasheda Akter', 30, '', 'rasheda@gmail.com', 1862887649, 'Chondonish', 2147483647, 'rasheda123');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `trn-date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `loginsystem`
--
ALTER TABLE `loginsystem`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pharmacist`
--
ALTER TABLE `pharmacist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sign_in`
--
ALTER TABLE `sign_in`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sign_up`
--
ALTER TABLE `sign_up`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `loginsystem`
--
ALTER TABLE `loginsystem`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `pharmacist`
--
ALTER TABLE `pharmacist`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `sign_in`
--
ALTER TABLE `sign_in`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `sign_up`
--
ALTER TABLE `sign_up`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
